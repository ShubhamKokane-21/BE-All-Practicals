#include<conio.h>
int main()
{

	int i,a,b,c;
        char st="asd";	
	printf("Hello");
	a=5;
	b=5;
	c=a+b;
	i=1;	
	while(i<5)
              printf("Hellow");  
	
}
