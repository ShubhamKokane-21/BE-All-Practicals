t1 = c * d
t2 = b +t1
t3 = e /f
t4 = t2 -t3
a = t4